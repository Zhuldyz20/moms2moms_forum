<?php 

$conn = mysqli_connect('localhost', 'dyessimzhanovaf21', 'dyessimzhanovaf21136', 'C354_dyessimzhanovaf21');


$user_id = 2;

if (!$conn) {
  die("Error connecting to database: " . mysqli_connect_error($conn));
  exit();
}


if (isset($_POST['action'])) {
  $post_id = $_POST['post_id'];
  $action = $_POST['action'];
  switch ($action) {
  	case 'like':
         $sql="INSERT INTO rating_info (user_id, post_id, rating_action) 
         	   VALUES ($user_id, $post_id, 'like') 
         	   ON DUPLICATE KEY UPDATE rating_action='like'";
         break;
  	 case 'unlike':
	 $sql="DELETE FROM rating_info WHERE user_id=$user_id AND post_id=$post_id";
         break;
  
      break;
  	default:
  		break;
  }


  mysqli_query($conn, $sql);
  echo getRating($post_id);
  exit();
}


function getLikes($id)
{
  global $conn;
  $sql = "SELECT COUNT(*) FROM rating_info 
  		  WHERE post_id = $id AND rating_action='like'";
  $rs = mysqli_query($conn, $sql);
  $result = mysqli_fetch_array($rs);
  return $result[0];
}

function getRating($id)
{
  global $conn;
  $rating = array();
  $likes_query = "SELECT COUNT(*) FROM rating_info WHERE post_id = $id AND rating_action='like'";
  $likes_rs = mysqli_query($conn, $likes_query);

  $likes = mysqli_fetch_array($likes_rs);
  
  $rating = [
  	'likes' => $likes[0],
  ];
  return json_encode($rating);
}
function userLiked($post_id)
{
  global $conn;
  global $user_id;
  $sql = "SELECT * FROM rating_info WHERE user_id=$user_id 
  		  AND post_id=$post_id AND rating_action='like'";
  $result = mysqli_query($conn, $sql);
  if (mysqli_num_rows($result) > 0) {
  	return true;
  }else{
  	return false;
  }
}


$sql = "SELECT * FROM posts";
$result = mysqli_query($conn, $sql);
$posts = mysqli_fetch_all($result, MYSQLI_ASSOC);